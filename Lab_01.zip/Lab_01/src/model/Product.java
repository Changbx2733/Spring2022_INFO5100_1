/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author dingxiaole
 */
public class Product {
    private String name;
    private String geog;
    private String date;
    private String tele;
    private String fax;
    private String email;    
    private String social;
    private String medical;
    private String health;
    private String bank;
    private String certi;
    private String vehicle;
    private String device;    
    private String linkedin;    
    private String internet;
    private String biom;
    private String fullf;    
    private String anyu;    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGeog() {
        return geog;
    }

    public void setGeog(String geog) {
        this.geog = geog;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTele() {
        return tele;
    }

    public void setTele(String tele) {
        this.tele = tele;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSocial() {
        return social;
    }

    public void setSocial(String social) {
        this.social = social;
    }

    public String getMedical() {
        return medical;
    }

    public void setMedical(String medical) {
        this.medical = medical;
    }

    public String getHealth() {
        return health;
    }

    public void setHealth(String health) {
        this.health = health;
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank;
    }

    public String getCerti() {
        return certi;
    }

    public void setCerti(String certi) {
        this.certi = certi;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkdln) {
        this.linkedin = linkdln;
    }

    public String getInternet() {
        return internet;
    }

    public void setInternet(String internet) {
        this.internet = internet;
    }

    public String getBiom() {
        return biom;
    }

    public void setBiom(String biom) {
        this.biom = biom;
    }

    public String getFullf() {
        return fullf;
    }

    public void setFullf(String fullf) {
        this.fullf = fullf;
    }

    public String getAnyu() {
        return anyu;
    }

    public void setAnyu(String anyu) {
        this.anyu = anyu;
    }
    
    
}
